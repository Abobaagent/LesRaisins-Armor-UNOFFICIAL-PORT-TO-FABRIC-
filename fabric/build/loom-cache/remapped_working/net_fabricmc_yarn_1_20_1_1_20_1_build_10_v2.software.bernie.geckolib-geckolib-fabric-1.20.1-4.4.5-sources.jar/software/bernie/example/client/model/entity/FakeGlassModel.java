package software.bernie.example.client.model.entity;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;
import software.bernie.example.client.renderer.entity.FakeGlassRenderer;
import software.bernie.example.entity.FakeGlassEntity;
import software.bernie.geckolib.GeckoLib;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.model.GeoModel;

/**
 * Example {@link GeoModel} for the {@link FakeGlassEntity}
 * @see FakeGlassRenderer
 */
public class FakeGlassModel extends DefaultedEntityGeoModel<FakeGlassEntity> {
	private static final Identifier REDSTONE_BLOCK_TEXTURE =
			new Identifier("minecraft", "textures/block/redstone_block.png");

	public FakeGlassModel() {
		super(new Identifier(GeckoLib.MOD_ID, "fake_glass"));
	}

	// We just want our texture to be the Redstone Block texture
	@Override
	public Identifier getTextureResource(FakeGlassEntity animatable) {
		return REDSTONE_BLOCK_TEXTURE;
	}

	// We want our entity to be translucent
	@Override
	public RenderLayer getRenderType(FakeGlassEntity animatable, Identifier texture) {
		return RenderLayer.getEntityTranslucent(texture);
	}
}
