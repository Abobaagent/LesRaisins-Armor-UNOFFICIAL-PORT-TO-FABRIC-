package software.bernie.example.registry;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterials;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.item.*;
import software.bernie.example.item.*;
import software.bernie.geckolib.GeckoLib;

public class ItemRegistry {

    public static final JackInTheBoxItem JACK_IN_THE_BOX = registerItem("jack_in_the_box", new JackInTheBoxItem(new Item.Settings()));

    public static final BlockItem FERTILIZER = registerItem("fertilizer", new BlockItem(BlockRegistry.FERTILIZER_BLOCK, new Item.Settings()));
    public static final BlockItem GECKO_HABITAT = registerItem("gecko_habitat", new GeckoHabitatItem(BlockRegistry.GECKO_HABITAT_BLOCK, new Item.Settings()));

    public static final GeckoArmorItem GECKO_ARMOR_HELMET = registerItem("gecko_armor_helmet", new GeckoArmorItem(ArmorMaterials.NETHERITE, ArmorItem.Type.HELMET, new Item.Settings()));
    public static final GeckoArmorItem GECKO_ARMOR_CHESTPLATE = registerItem("gecko_armor_chestplate", new GeckoArmorItem(ArmorMaterials.NETHERITE, ArmorItem.Type.CHESTPLATE, new Item.Settings()));
    public static final GeckoArmorItem GECKO_ARMOR_LEGGINGS = registerItem("gecko_armor_leggings", new GeckoArmorItem(ArmorMaterials.NETHERITE, ArmorItem.Type.LEGGINGS, new Item.Settings()));
    public static final GeckoArmorItem GECKO_ARMOR_BOOTS = registerItem("gecko_armor_boots", new GeckoArmorItem(ArmorMaterials.NETHERITE, ArmorItem.Type.BOOTS, new Item.Settings()));

    public static final WolfArmorItem WOLF_ARMOR_HELMET = registerItem("wolf_armor_helmet", new WolfArmorItem(ArmorMaterials.DIAMOND, ArmorItem.Type.HELMET, new Item.Settings()));
    public static final WolfArmorItem WOLF_ARMOR_CHESTPLATE = registerItem("wolf_armor_chestplate", new WolfArmorItem(ArmorMaterials.DIAMOND, ArmorItem.Type.CHESTPLATE, new Item.Settings()));
    public static final WolfArmorItem WOLF_ARMOR_LEGGINGS = registerItem("wolf_armor_leggings", new WolfArmorItem(ArmorMaterials.DIAMOND, ArmorItem.Type.LEGGINGS, new Item.Settings()));
    public static final WolfArmorItem WOLF_ARMOR_BOOTS = registerItem("wolf_armor_boots", new WolfArmorItem(ArmorMaterials.DIAMOND, ArmorItem.Type.BOOTS, new Item.Settings()));
    
    public static final SpawnEggItem BAT_SPAWN_EGG = registerItem("bat_spawn_egg", new SpawnEggItem(EntityRegistry.BAT, 0x1F1F1F, 0x0D0D0D, new Item.Settings()));
    public static final SpawnEggItem BIKE_SPAWN_EGG = registerItem("bike_spawn_egg", new SpawnEggItem(EntityRegistry.BIKE, 0xD3E3E6, 0xE9F1F5, new Item.Settings()));
    public static final SpawnEggItem RACE_CAR_SPAWN_EGG = registerItem("race_car_spawn_egg", new SpawnEggItem(EntityRegistry.RACE_CAR, 0x9E1616, 0x595959, new Item.Settings()));
    public static final SpawnEggItem PARASITE_SPAWN_EGG = registerItem("parasite_spawn_egg", new SpawnEggItem(EntityRegistry.PARASITE, 0x302219, 0xACACAC, new Item.Settings()));
    public static final SpawnEggItem MUTANT_ZOMBIE_SPAWN_EGG = registerItem("mutant_zombie_spawn_egg", new SpawnEggItem(EntityRegistry.MUTANT_ZOMBIE, 0x3C6236, 0x579989, new Item.Settings()));
    public static final SpawnEggItem FAKE_GLASS_SPAWN_EGG = registerItem("fake_glass_spawn_egg", new SpawnEggItem(EntityRegistry.FAKE_GLASS, 0xDD0000, 0xD8FFF7, new Item.Settings()));
    public static final SpawnEggItem COOL_KID_SPAWN_EGG = registerItem("cool_kid_spawn_egg", new SpawnEggItem(EntityRegistry.COOL_KID, 0x5F2A31, 0x6F363E, new Item.Settings()));
    public static final SpawnEggItem GREMLIN_SPAWN_EGG = registerItem("gremlin_spawn_egg", new SpawnEggItem(EntityRegistry.GREMLIN, 0x505050, 0x606060, new Item.Settings()));
    
    public static final ItemGroup ITEM_GROUP = Registry.register(Registries.ITEM_GROUP, new Identifier(GeckoLib.MOD_ID, "geckolib_examples"), FabricItemGroup
            .builder()
            .displayName(Text.translatable("itemGroup.geckolib.geckolib_examples"))
            .icon(() -> new ItemStack(ItemRegistry.JACK_IN_THE_BOX))
            .entries((enabledFeatures, entries) -> {
                entries.add(ItemRegistry.JACK_IN_THE_BOX);
                entries.add(ItemRegistry.FERTILIZER);
                entries.add(ItemRegistry.GECKO_HABITAT);
                entries.add(ItemRegistry.GECKO_ARMOR_HELMET);
                entries.add(ItemRegistry.GECKO_ARMOR_CHESTPLATE);
                entries.add(ItemRegistry.GECKO_ARMOR_LEGGINGS);
                entries.add(ItemRegistry.GECKO_ARMOR_BOOTS);
                entries.add(ItemRegistry.WOLF_ARMOR_HELMET);
                entries.add(ItemRegistry.WOLF_ARMOR_CHESTPLATE);
                entries.add(ItemRegistry.WOLF_ARMOR_LEGGINGS);
                entries.add(ItemRegistry.WOLF_ARMOR_BOOTS);
                entries.add(ItemRegistry.BAT_SPAWN_EGG);
                entries.add(ItemRegistry.BIKE_SPAWN_EGG);
                entries.add(ItemRegistry.RACE_CAR_SPAWN_EGG);
                entries.add(ItemRegistry.PARASITE_SPAWN_EGG);
                entries.add(ItemRegistry.MUTANT_ZOMBIE_SPAWN_EGG);
                entries.add(ItemRegistry.GREMLIN_SPAWN_EGG);
                entries.add(ItemRegistry.FAKE_GLASS_SPAWN_EGG);
                entries.add(ItemRegistry.COOL_KID_SPAWN_EGG);
            }).build());

    public static <I extends Item> I registerItem(String name, I item) {
        return Registry.register(Registries.ITEM, new Identifier(GeckoLib.MOD_ID, name), item);
    }
}
