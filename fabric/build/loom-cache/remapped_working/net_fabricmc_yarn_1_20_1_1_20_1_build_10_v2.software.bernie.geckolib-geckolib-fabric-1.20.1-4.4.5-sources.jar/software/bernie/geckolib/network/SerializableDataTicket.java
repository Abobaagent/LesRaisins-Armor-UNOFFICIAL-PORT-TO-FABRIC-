package software.bernie.geckolib.network;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import software.bernie.geckolib.core.object.DataTicket;

/**
 * Network-compatible {@link software.bernie.geckolib.core.object.DataTicket} implementation.
 * Used for sending data from server -> client in an easy manner
 */
public abstract class SerializableDataTicket<D> extends DataTicket<D> {
	public SerializableDataTicket(String id, Class<? extends D> objectType) {
		super(id, objectType);
	}

	/**
	 * Encode the object to a packet buffer for transmission
	 * @param data The object to be serialized
	 * @param buffer The buffer to serialize the object to
	 */
	public abstract void encode(D data, PacketByteBuf buffer);

	/**
	 * Decode the object from a packet buffer after transmission
	 * @param buffer The buffer to deserialize the object from
	 * @return A new instance of your data object
	 */
	public abstract D decode(PacketByteBuf buffer);

	// Pre-defined typings for use

	/**
	 * Generate a new {@code SerializableDataTicket<Double>} for the given id
	 * @param id The unique id of your ticket. Include your modid
	 */
	public static SerializableDataTicket<Double> ofDouble(Identifier id) {
		return new SerializableDataTicket<>(id.toString(), Double.class) {
			@Override
			public void encode(Double data, PacketByteBuf buffer) {
				buffer.writeDouble(data);
			}

			@Override
			public Double decode(PacketByteBuf buffer) {
				return buffer.readDouble();
			}
		};
	}

	/**
	 * Generate a new {@code SerializableDataTicket<Float>} for the given id
	 * @param id The unique id of your ticket. Include your modid
	 */
	public static SerializableDataTicket<Float> ofFloat(Identifier id) {
		return new SerializableDataTicket<>(id.toString(), Float.class) {
			@Override
			public void encode(Float data, PacketByteBuf buffer) {
				buffer.writeFloat(data);
			}

			@Override
			public Float decode(PacketByteBuf buffer) {
				return buffer.readFloat();
			}
		};
	}

	/**
	 * Generate a new {@code SerializableDataTicket<Boolean>} for the given id
	 * @param id The unique id of your ticket. Include your modid
	 */
	public static SerializableDataTicket<Boolean> ofBoolean(Identifier id) {
		return new SerializableDataTicket<>(id.toString(), Boolean.class) {
			@Override
			public void encode(Boolean data, PacketByteBuf buffer) {
				buffer.writeBoolean(data);
			}

			@Override
			public Boolean decode(PacketByteBuf buffer) {
				return buffer.readBoolean();
			}
		};
	}

	/**
	 * Generate a new {@code SerializableDataTicket<Integer>} for the given id
	 * @param id The unique id of your ticket. Include your modid
	 */
	public static SerializableDataTicket<Integer> ofInt(Identifier id) {
		return new SerializableDataTicket<>(id.toString(), Integer.class) {
			@Override
			public void encode(Integer data, PacketByteBuf buffer) {
				buffer.writeVarInt(data);
			}

			@Override
			public Integer decode(PacketByteBuf buffer) {
				return buffer.readVarInt();
			}
		};
	}

	/**
	 * Generate a new {@code SerializableDataTicket<String>} for the given id
	 * @param id The unique id of your ticket. Include your modid
	 */
	public static SerializableDataTicket<String> ofString(Identifier id) {
		return new SerializableDataTicket<>(id.toString(), String.class) {
			@Override
			public void encode(String data, PacketByteBuf buffer) {
				buffer.writeString(data);
			}

			@Override
			public String decode(PacketByteBuf buffer) {
				return buffer.readString();
			}
		};
	}

	/**
	 * Generate a new {@code SerializableDataTicket<Enum>} for the given id
	 * @param id The unique id of your ticket. Include your modid
	 */
	public static <E extends Enum<E>> SerializableDataTicket<E> ofEnum(Identifier id, Class<E> enumClass) {
		return new SerializableDataTicket<>(id.toString(), enumClass) {
			@Override
			public void encode(E data, PacketByteBuf buffer) {
				buffer.writeString(data.toString());
			}

			@Override
			public E decode(PacketByteBuf buffer) {
				return Enum.valueOf(enumClass, buffer.readString());
			}
		};
	}
}
