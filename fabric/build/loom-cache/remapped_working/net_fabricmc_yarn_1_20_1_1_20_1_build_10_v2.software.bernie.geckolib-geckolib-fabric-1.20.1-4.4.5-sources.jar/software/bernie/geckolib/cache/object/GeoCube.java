package software.bernie.geckolib.cache.object;

import net.minecraft.util.math.Vec3d;

/**
 * Baked cuboid for a {@link GeoBone}
 */
public record GeoCube(GeoQuad[] quads, Vec3d pivot, Vec3d rotation, Vec3d size, double inflate, boolean mirror) {}
