package software.bernie.geckolib.animatable.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.Model;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.item.BuiltinModelItemRenderer;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.mixins.fabric.ItemRendererAccessor;

/**
 * Internal interface for safely providing a custom renderer instances at runtime.<br>
 * This can be safely instantiated as a new anonymous class inside your {@link Item} class
 */
public interface RenderProvider {
    RenderProvider DEFAULT = new RenderProvider() {};

    static RenderProvider of(ItemStack itemStack) {
        return of(itemStack.getItem());
    }

    static RenderProvider of(Item item) {
        if (item instanceof GeoItem geoItem)
            return (RenderProvider)geoItem.getRenderProvider().get();

        return DEFAULT;
    }

    default BuiltinModelItemRenderer getCustomRenderer() {
        return ((ItemRendererAccessor)MinecraftClient.getInstance().getItemRenderer()).getBlockEntityRenderer();
    }


    default Model getGenericArmorModel(LivingEntity livingEntity, ItemStack itemStack, EquipmentSlot equipmentSlot, BipedEntityModel<LivingEntity> original) {
        BipedEntityModel<LivingEntity> replacement = getHumanoidArmorModel(livingEntity, itemStack, equipmentSlot, original);

        if (replacement != original) {
            original.copyBipedStateTo(replacement);

            return replacement;
        }

        return original;
    }

    default BipedEntityModel<LivingEntity> getHumanoidArmorModel(LivingEntity livingEntity, ItemStack itemStack, EquipmentSlot equipmentSlot, BipedEntityModel<LivingEntity> original) {
        return original;
    }
}